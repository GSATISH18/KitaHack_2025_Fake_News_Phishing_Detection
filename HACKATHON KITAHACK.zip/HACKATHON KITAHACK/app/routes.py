import joblib
from flask import request, jsonify

# ✅ Load correct models and vectorizers (file names must match your actual files)
phishing_model = joblib.load("app/model_phishing.pkl")
phishing_vectorizer = joblib.load("app/tfidf_vectorizer_phish.pkl")

fake_news_model = joblib.load("app/fake_news_model.pkl")
fake_vectorizer = joblib.load("app/tfidf_vectorizer_fake.pkl")

def register_routes(app):
    @app.route('/')
    def home():
        return "🚀 AI-Powered Fake News & Phishing Detection API Running!"

    @app.route('/predict/phishing', methods=['POST'])
    def predict_phishing():
        try:
            data = request.get_json()
            text = data.get("text")
            if not text:
                return jsonify({'error': 'No text provided'}), 400
        except Exception as e:
            return jsonify({'error': 'Invalid JSON provided', 'message': str(e)}), 400

        vec = phishing_vectorizer.transform([text])
        
        # Get prediction probabilities for the "phishing" class
        probability = phishing_model.predict_proba(vec)[0][1]  # Probability of being phishing
        
        # Adjust threshold for phishing (can modify this threshold based on results)
        threshold_phishing = 0.60  # If probability is above 60%, it's "Phishing", else "Legitimate"
        
        # Make decision based on threshold
        label = "Phishing URL" if probability > threshold_phishing else "Legitimate URL"
        
        return jsonify({'prediction': label})

    @app.route('/predict/fake-news', methods=['POST'])
    def predict_fake_news():
        try:
            data = request.get_json()
            text = data.get("text")
            if not text:
                return jsonify({'error': 'No text provided'}), 400
        except Exception as e:
            return jsonify({'error': 'Invalid JSON provided', 'message': str(e)}), 400

        vec = fake_vectorizer.transform([text])
        
        # Get prediction probabilities for the "fake" class
        probability = fake_news_model.predict_proba(vec)[0][1]  # Probability of being fake news
        
        # Adjust threshold for fake news (you can modify this threshold)
        threshold_fake_news = 0.60  # If probability is above 60%, it's "Fake News", else "Real News"
        
        # Make decision based on threshold
        label = "Fake News" if probability > threshold_fake_news else "Real News"
        
        return jsonify({'prediction': label})
